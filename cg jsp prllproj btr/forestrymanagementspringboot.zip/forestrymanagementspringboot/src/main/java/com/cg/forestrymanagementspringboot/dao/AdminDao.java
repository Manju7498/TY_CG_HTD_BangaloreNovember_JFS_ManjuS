package com.cg.forestrymanagementspringboot.dao;

import com.cg.forestrymanagementspringboot.dto.AdminBean;

public interface AdminDao {
	public AdminBean login(AdminBean bean);

	public boolean register(AdminBean bean);

}
