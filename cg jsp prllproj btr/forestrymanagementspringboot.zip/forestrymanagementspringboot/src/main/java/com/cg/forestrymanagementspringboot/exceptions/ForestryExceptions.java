package com.cg.forestrymanagementspringboot.exceptions;

@SuppressWarnings("serial")
public class ForestryExceptions extends RuntimeException {
	public ForestryExceptions() {
	}
}
