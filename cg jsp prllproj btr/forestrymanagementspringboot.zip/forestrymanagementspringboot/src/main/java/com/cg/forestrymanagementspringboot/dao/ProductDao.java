package com.cg.forestrymanagementspringboot.dao;

import java.util.List;

import com.cg.forestrymanagementspringboot.dto.ProductBean;

public interface ProductDao {
	public boolean addProduct(ProductBean product);

	public ProductBean getProduct(int productId);

	public List<ProductBean> getAllProducts();

	public boolean deleteProduct(int productId);

	public boolean updateProduct(ProductBean product);
}
