package com.cg.forestrymanagementspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForestrymanagementspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForestrymanagementspringbootApplication.class, args);
	}
}
