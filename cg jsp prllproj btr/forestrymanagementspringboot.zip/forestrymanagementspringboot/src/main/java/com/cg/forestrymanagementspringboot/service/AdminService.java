package com.cg.forestrymanagementspringboot.service;

import com.cg.forestrymanagementspringboot.dto.AdminBean;

public interface AdminService {
	public AdminBean login(AdminBean bean);

	public boolean register(AdminBean bean);

}
